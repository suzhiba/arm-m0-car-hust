/**********************************************************************************
 *						Init_motor.h ----- Header Functions
 *		(c) Copyright 2013 HUST RENESAS LAB,The Department of CSE, HUST
 *                       	 All Rights Reserved
 *Filename             :   Init_motor.h
 *Programmer(s)        :   Chen Xi
 *Description          :
 *Modification History :
 *01a 2013-8-1 20:40:00
**********************************************************************************/
#ifndef __INIT_GPIO_H 
#define __INIT_GPIO_H

#include "include.h"

void Init_GPIO( void );

#endif          //  End of __INIT_MOTOR_H
