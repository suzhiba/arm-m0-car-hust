

/*-----------------------------------------------------------------------------
 *  Include Files
 *-----------------------------------------------------------------------------*/
#include "protect.h"

/*-----------------------------------------------------------------------------
 *  Functions
 *-----------------------------------------------------------------------------*/

void TeleControl ( void )
{
    static char teleControlCounter = 0;
    static char Counter = 0;
    uint8_t switchTeleCtrl = 0;
    uint8_t infraedRayValue = 0;

    switchTeleCtrl = !!(gl_ucSwitchValue & 0x08);

    if(switchTeleCtrl)
    {
        infraedRayValue = Remote();

        if(infraedRayValue)
        {
            teleControlCounter ++;
        }

        Counter ++;

        if(teleControlCounter > 6)
        {
            gl_iPattern = 9;
        }
        else
        {
            if(Counter > 50)
            {
                teleControlCounter = 0;
                Counter = 0;
            }
        }
    }



}		/* -----  end of function TeleControl  ----- */
