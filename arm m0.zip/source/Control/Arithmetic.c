
#include "Arithmetic.h"


void Control(void)
{
    //int iErrTemp = 0;
    int servoAngleTemp = 0;
//	static int s_iNowErr=0 ;
	static int s_iLastErr2=0;
//	static int s_iPreErr = 0;
	float kd;//pd����
    gl_iNowErr = GetErr(); 

    servoAngleTemp = gl_iNowErr;


    gl_cServoAngle = servoAngleTemp;

	

	if(servoAngleTemp < 0)
	{
	    servoAngleTemp = 0 - servoAngleTemp;
		
	}
	if((servoAngleTemp >= 0) && (servoAngleTemp < 6))
	{			
        SpeedOut(gl_iStraightSpeed, 0);
		    SetServoAngle(gl_cServoAngle);
	}
	else if(servoAngleTemp < 15) 
	{			kd=0.1;
				gl_cServoAngle=gl_cServoAngle+kd*(gl_cServoAngle-s_iLastErr2);
				SpeedOut(gl_iStraightSpeed, gl_cServoAngle);
        //SpeedOut(gl_iR600Speed, gl_cServoAngle);//�޸���
		    SetServoAngle(gl_cServoAngle);
				//PWMOut(0,0,0,0);
}

	
	else if(servoAngleTemp < 23)	
	{			
				kd=0.2;
				gl_cServoAngle=gl_cServoAngle+kd*(gl_cServoAngle-s_iLastErr2);
				
        SpeedOut(gl_iR600Speed, gl_cServoAngle);
				SetServoAngle(gl_cServoAngle);
				
	}
		else if(servoAngleTemp<28){
				kd=0.23;
				gl_cServoAngle=gl_cServoAngle+kd*(gl_cServoAngle-s_iLastErr2);
				
        SpeedOut(gl_iR450Speed, gl_cServoAngle);
				SetServoAngle(gl_cServoAngle);
	}
	else if(servoAngleTemp<35){
				kd=0.26;
				gl_cServoAngle=gl_cServoAngle+kd*(gl_cServoAngle-s_iLastErr2);
        SpeedOut(gl_iR450Speed, gl_cServoAngle);
				SetServoAngle(gl_cServoAngle);
	}
	
	else if(servoAngleTemp<50){
				kd=0.30;
				gl_cServoAngle=gl_cServoAngle+kd*(gl_cServoAngle-s_iLastErr2);
				
        SpeedOut(gl_iR450Speed, gl_cServoAngle);
				SetServoAngle(gl_cServoAngle);
	}
	else  
	{			kd=0.35;
				gl_cServoAngle=gl_cServoAngle+kd*(gl_cServoAngle-s_iLastErr2);
        SpeedOut(gl_iR450Speed, gl_cServoAngle);
		    SetServoAngle(gl_cServoAngle);
	}


		s_iLastErr2=gl_iNowErr;
}
/************************************************************************
 * Function         RightTrace                                              
 * Usage            Right Trace                           
 * Argument         NONE                                                
 * Return value     NONE                                                
 * Modification History:                                                
 * 01a 2012-12-13 22:54:33   
 *
 ************************************************************************/
void RightTrace (void) 
{
    gl_iNowErr = GetErr();

    if(gl_iNowErr > 0)
    {
        gl_cServoAngle = gl_iNowErr;//
    }
    else if(gl_iNowErr < 0)
    {
        gl_cServoAngle = gl_iNowErr / 2;
    }
    SetServoAngle(gl_cServoAngle);
    SpeedOut(gl_iR600Speed, gl_cServoAngle);

   if(gl_iNowErr > 40)
    {
        gl_iPattern = 21;
        gl_cServoAngle = 60;//50  �޸���
        SetServoAngle(gl_cServoAngle);
        PWMOut4(0,100,0,0);
    }
    if(gl_uiDigitalSensor & 0x0100)
    {
        gl_iPattern = 11;
        gl_cServoAngle = -7;
        SetServoAngle(gl_cServoAngle);
        PWMOut4(30,15,15,60);
        gl_ulTimerCnt = 0;
        while(gl_ulTimerCnt < 1);
    }
}		/* -----  end of function RightTrace  ----- */

/************************************************************************
 * Function         LeftTrace                                              
 * Usage            Left Trace                           
 * Argument         NONE                                                
 * Return value     NONE                                                
 * Modification History:                                                
 * 01a 2012-12-14 00:07:14   
 *
 ************************************************************************/
void LeftTrace (void) 
{
    gl_iNowErr = GetErr();

    if(gl_iNowErr < 0)
    {
        gl_cServoAngle = gl_iNowErr;//
    }
    else if(gl_iNowErr > 0)
    {
        gl_cServoAngle = gl_iNowErr / 2;
    }
    SetServoAngle(gl_cServoAngle); 
    SpeedOut(gl_iR600Speed, gl_cServoAngle);

    if(gl_iNowErr < -40)
    {
        gl_iPattern = 22;
        gl_cServoAngle = -58;//-50
        SetServoAngle(gl_cServoAngle);
        PWMOut4(10,10,30,100);
    }
    if(gl_uiDigitalSensor & 0x0004)
    {
        gl_iPattern = 11;
        gl_cServoAngle = 7;
        SetServoAngle(gl_cServoAngle);
        PWMOut4(15,60,30,15);
        gl_ulTimerCnt = 0;
        while(gl_ulTimerCnt < 1);
    }
}		/* -----  end of function LeftTrace  ----- */
/******************************************************************************
**                            End Of File
******************************************************************************/
