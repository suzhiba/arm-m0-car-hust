#include    "motor_control.h"
 //mod											��Su Zhiba
#define TABLE_DIMENSION   62

const uint8_t gl_speedDifference[3][TABLE_DIMENSION]  = {						
{100, 98, 96, 95, 93,	91, 89, 87, 86, 84,	82, 80, 79, 77, 75,	73, 72, 70, 68, 67,	65, 63, 61, 60, 58,	56, 55, 53, 52, 50,
48, 47, 45, 43, 42,	40, 38, 37, 36, 34,	32, 30, 27, 26, 24,	22, 21, 19, 17, 16,	15, 13, 12, 10, 9,	7, 6, 5, 3, 2,1,0},
{100, 98, 96, 95, 93,	91, 90, 88, 87, 85,	84, 82, 81, 79, 78,	77, 75, 74, 73, 71,	70, 69, 68, 67, 66,	64, 63, 62, 61, 60,
59, 58, 57, 56, 56,	55, 54, 53, 52, 51,	51, 50, 49, 48, 48,	47, 46, 46, 45, 44,	44, 43, 43, 42, 41,	41, 40, 40, 39, 39,38,38},
{100, 100, 100, 100, 100,	100, 100, 99, 99, 99,	99, 98, 98, 98, 98,	97, 97, 96, 96, 96,	95, 95, 94, 94, 93,	93, 92, 91, 91, 90,
90, 89, 88, 88, 87,	86, 86, 85, 84, 84,	83, 82, 81, 81, 80,	79, 78, 77, 76, 76,	75, 74, 73, 72, 71,	70, 70, 69, 68, 67,66,65}};
	/*{100, 98, 96, 95, 93,	91, 89, 87, 86, 84,	82, 80, 79, 77, 75,	73, 72, 70, 68, 67,	65, 63, 61, 60, 58,	56, 55, 53, 52, 50,
48, 47, 45, 43, 42,	40, 39, 37, 36, 34,	32, 31, 29, 28, 26,	25, 23, 22, 20, 19,	18, 16, 15, 13, 12,	10, 9, 8, 6, 5,},
{100, 98, 96, 95, 93,	91, 90, 88, 87, 85,	84, 82, 81, 79, 78,	77, 75, 74, 73, 71,	70, 69, 68, 67, 66,	64, 63, 62, 61, 60,
59, 58, 57, 56, 56,	55, 54, 53, 52, 51,	51, 50, 49, 48, 48,	47, 46, 46, 45, 44,	44, 43, 43, 42, 41,	41, 40, 40, 39, 39,},
{100, 100, 100, 100, 100,	100, 100, 99, 99, 99,	99, 98, 98, 98, 98,	97, 97, 96, 96, 96,	95, 95, 94, 94, 93,	93, 92, 91, 91, 90,
90, 89, 88, 88, 87,	86, 86, 85, 84, 84,	83, 82, 81, 81, 80,	79, 78, 77, 76, 76,	75, 74, 73, 72, 71,	70, 70, 69, 68, 67,}};
*/
/*{100, 98, 96, 95, 93,	91, 89, 87, 86, 84,	82, 80, 79, 77, 75,	73, 72, 70, 68, 67,	65, 63, 61, 60, 58,	56, 55, 53, 52, 50,
47, 46, 44, 42, 41,	39, 38, 36, 35, 33,	31, 30, 28, 27, 24,	23, 21, 20, 18, 17,	16, 14, 13, 10, 9,	7, 6, 5, 3, 2,},
{100, 98, 96, 95, 93,	91, 89, 87, 86, 84,	83, 81, 80, 77, 76,	75, 73, 72, 71, 69,	68, 67, 66, 65, 64,	62, 61, 60, 58, 57,
56, 55, 54, 53, 53,	52, 51, 50, 49, 48,	47, 46, 45, 44, 44,	43, 42, 41, 40, 39,	38, 37, 36, 35, 34,	34, 33, 33, 32, 32,},
{100, 100, 100, 100, 100,	100, 100, 99, 99, 99,	99, 98, 98, 98, 98,	97, 97, 96, 96, 96,	95, 95, 94, 94, 93,	93, 92, 91, 91, 90,
90, 89, 88, 88, 87,	86, 86, 85, 84, 84,	83, 82, 81, 81, 80,	79, 78, 77, 76, 76,	75, 74, 73, 72, 71,	70, 70, 69, 68, 67,}};*/



/*-------------------------------------------------------------------
  *   Notes       :    �����ٵ��ٶ������angle Ϊ���ٽǶȣ��������Ϊ�ο����ڲ�������ݲ��ٱ��б��������ڲ��PWM
                       ����������80%�� ���ٲ�����ڲ�Ϊ����60%�����ڲ����Ϊ 80% * 60% = 48%
					   ��˿���ʱ����Ҫ������PWMռ�ձ�Ϊ����׼�����ռ�ձȣ���������Ϊ�������ó�
--------------------------------------------------------------------*/

//  �������������ǰ��Ϊ��׼
void PWMOut(int8_t pwmduty, int8_t angle)
{
    char InsideRDiff = 0;			// Speed differential proportion of inside rear wheel      positive PWM  �����ڲ��ٶ�΢�ֱ��� 
    char InsideFDiff = 0;			// Speed differential proportion of inside front wheel     positive PWM		
    char OutsideRDiff = 0;			// Speed differential proportion of outside rear wheel     positive PWM
	
    int pwmdutyTemp = 0;
    int angleTemp = 0;
	
    pwmdutyTemp = pwmduty;
    angleTemp   = angle;

	if (angleTemp > 0) 
	{
		if (angleTemp > (TABLE_DIMENSION - 1))               //  ��ֹѰַ���
		{
		    angleTemp = TABLE_DIMENSION - 1;
		}
		InsideRDiff  = gl_speedDifference[0][angleTemp];
        InsideFDiff  = gl_speedDifference[1][angleTemp];
        OutsideRDiff = gl_speedDifference[2][angleTemp];
		PWMOut4(PWM_OUTSIDE_R, pwmdutyTemp, PWM_INSIDE_R , PWM_INSIDE_F);
	}
	else
	{
		angleTemp = 0 - angleTemp;
		if (angleTemp > (TABLE_DIMENSION - 1))               //  ��ֹѰַ���
		{
		    angleTemp = TABLE_DIMENSION - 1;
		}
		InsideRDiff  = gl_speedDifference[0][angleTemp];
        InsideFDiff  = gl_speedDifference[1][angleTemp];
        OutsideRDiff = gl_speedDifference[2][angleTemp];
		PWMOut4(PWM_INSIDE_R , PWM_INSIDE_F, PWM_OUTSIDE_R , pwmdutyTemp);
	}
}


#ifdef ENCODER_USE
void SpeedOut (int speed, int angle) 
{
    int speedErr = 0;
	char motorPWM = 0; //������ռ�ձ�
	int temp;
	speedErr = gl_iCurSpeed - speed;    
		if (angle<0)
			temp=0-angle;

		//if(angle
  if(temp>26){
    if(speedErr < -50)
    {
        motorPWM = 70;
    }
    else if(speedErr < -40)
    {
        motorPWM = 60;
    }
    else if(speedErr < -30)
    {
        motorPWM = 50;
    }
    else if(speedErr < -25)
    {
        motorPWM = 40;
    }
    else if(speedErr < -20)
    {
        motorPWM = 30;
    }
    else if(speedErr < -10)
    {
        motorPWM = 20;
    }
    else if(speedErr < -5)
    {
        motorPWM = 10;
    }
    else if(speedErr < 0)
    {
        motorPWM = 5;
    }
    else 
    {
        motorPWM = -35;
    }
}else{
		   if(speedErr < -50)
    {
        motorPWM = 90;
    }
    else if(speedErr < -40)
    {
        motorPWM = 80;
    }
    else if(speedErr < -30)
    {
        motorPWM = 70;
    }
    else if(speedErr < -25)
    {
        motorPWM = 60;
    }
    else if(speedErr < -20)
    {
        motorPWM = 50;
    }
    else if(speedErr < -10)
    {
        motorPWM = 40;
    }
    else if(speedErr < -5)
    {
        motorPWM = 30;
    }
    else if(speedErr < 0)
    {
        motorPWM = 20;
    }
		else{
			motorPWM=-15;

}

}


	if(gl_iPattern == 9)
	{
		gl_cMotorPWM = 0;
		PWMOut4(0,0,0,0);
	}
	else
	{
        gl_cMotorPWM = motorPWM;
		PWMOut(gl_cMotorPWM, angle);
	}
    
}		/* -----  end of function SpeedOut  ----- */
#else
void SpeedOut (int speed, int angle) 
{
    char motorPWM;
    motorPWM = (char)speed;

	if(gl_iPattern == 9)
	{
		gl_cMotorPWM = 0;
		PWMOut4(0,0,0,0);
	}
    else
    {
        gl_cMotorPWM = motorPWM;
        PWMOut(speed, angle);
    }
}		/* -----  end of function SpeedOut  ----- */
#endif

